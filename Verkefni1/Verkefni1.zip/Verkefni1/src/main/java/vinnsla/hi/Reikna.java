package vinnsla.hi;

/*******************************************************
 * Nafn: María Rós Kaldalóns
 * T-póstur: mrk9@hi.is
 * Lýsing: Abstract aðferð sem tekur inn tvær heiltölur
 * a og b
 *
 *********************************************************/
public interface Reikna {
    int reikna(int a, int b);
}
